-----

<p align="center">
<img src="https://repository-images.githubusercontent.com/511306162/fbf9f42b-8aee-4d1a-8f2f-5b68285736a7", width="500", height="500">
</p>

-----

### <p align="center">☠️ Brute ☠️</p>

<br><br>
<p align="center">
<strong>
Brute is the best (imo) L4 DoS tool in Python3.
<br><br>
It will flood the victim's router with UDP packets, so even if there are no ports opened,
<br>
the router will still be overwhelmed and slowed down.
<br><br>
Brute allows you to DoS Fivem, Minecraft, or even normal servers.
<br>
But it can also down a simple family network.
<br><br><br>
</strong>
<img src="https://cdn.discordapp.com/attachments/940036299941904405/994447869736128573/zyro-image_7.png" width="500", height="400">
</p>
<br>

-----

### <p align="center">📀 Dependencies 📀</p>

<p align="center"><strong><i>In order for the program to work, you have to install these ressources:</i></strong</p>

<br><br>
* <a href="https://www.python.org/ftp/python/3.9.13/python-3.9.13-amd64.exe">Python3</a>
* `pip install -U -r requirements.txt`
<br><br>

-----

### <p align="center">⭐ Features ⭐</p>

<br><br>
<strong>+ The only limit... is you! The faster your connection is, the more powerful will be the attack</strong>
<br>
<strong>+ Show informations about the attack in real time</strong>
<br>
<strong>+ Can down servers but also family networks</strong>
<br>

<p align="right">
<img src="https://repository-images.githubusercontent.com/511306162/fbf9f42b-8aee-4d1a-8f2f-5b68285736a7" width="250", height="250">
</p>

<br>
<strong>- Only works on networks without a firewall (but who uses firewalls anyways 😂)</strong>
<br><br>

-----

### <p align="center">🎯 Levels 🎯</p>

<p align="center"><strong><i>This section shows the "levels" of this project, from 0/5 ⚪ to 5/5 ⚫!</i></strong</p>
<p align="center"><strong><i>⚪🟢🔵🔴🟣⚫</i></strong</p>

<br><br>
* Time: 🔵
* Complexity: 🔵
* Service: ⚫
<br><br>

-----

### <p align="center">💡 Ideas 💡</p>

<p align="center"><strong><i>Feel free to make a pull request on this repository to submit any idea!</i></strong</p>

<br><br>
* Add a L7 option
<br><br>

-----

### <p align="center">📌 Disclaimer 📌</p>

<br><br>
* ***Please use this program only for educational purposes.***
* ***It is not meant to be used in any malicious way, and I decline any responsibility for what you do with it.***
<br><br>

-----

### <p align="center">billythegoat356</p>
